using System;
//using System.Data.SqlClient;

/// <summary>
/// Summary description for LogInfo
/// </summary>
public class LogInfo
{
    private static DataClassesDataContext objMain = new DataClassesDataContext();
    public LogInfo()
    {
        //s
        // TODO: Add constructor logic here
        //
    }
    public static void LockLogInfo( string UserId, string PageName, string TypeOfEvent, string EventDetail, string IPAddress, DateTime Log_Datetime)
    {
        //SqlConnection connection = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["conn_stgring"].ConnectionString);
        //SqlCommand cmd = new SqlCommand();
        //connection.Open();
        //cmd.Connection = connection;
        //cmd.CommandText = "insert into Log_Student(UserId,PageName,TypeOfEvent,EventDetail,IPAddress,Log_Datetime)values(@UserId,@PageName,@TypeOfEvent,@EventDetail,@IPAddress,@Log_Datetime)";
        //cmd.Parameters.Add("@UserId", SqlDbType.VarChar, 10).Value = UserId;
        //cmd.Parameters.Add("@PageName", SqlDbType.VarChar, 50).Value = PageName;
        //cmd.Parameters.Add("@IPAddress", SqlDbType.VarChar, 15).Value = IPAddress;
        //cmd.Parameters.Add("@Log_Datetime", SqlDbType.DateTime, 30).Value = Log_Datetime;
        //cmd.Parameters.Add("@TypeOfEvent", SqlDbType.VarChar, 50).Value = TypeOfEvent;
        //cmd.Parameters.Add("@EventDetail", SqlDbType.VarChar).Value = EventDetail;
        //cmd.ExecuteScalar();
        //connection.Close();

        try
        {
            DateTime Insert_LogDatetime = new DateTime();
            Insert_LogDatetime = DateTime.Parse(Log_Datetime.ToString(), System.Globalization.CultureInfo.CreateSpecificCulture("en-AU").DateTimeFormat);

            WebSiteLog ObjTblWebSiteLog = new WebSiteLog();

            ObjTblWebSiteLog.UserID = UserId;
            ObjTblWebSiteLog.PageName = PageName;
            ObjTblWebSiteLog.TypeOfEvent = TypeOfEvent;
            ObjTblWebSiteLog.EventDetail = EventDetail;
            ObjTblWebSiteLog.IPAddress = IPAddress;
            ObjTblWebSiteLog.Log_Datetime = Insert_LogDatetime;

            objMain.WebSiteLogs.InsertOnSubmit(ObjTblWebSiteLog);
            objMain.SubmitChanges();
        }
        catch
        {
            throw;
        }
    }    
}