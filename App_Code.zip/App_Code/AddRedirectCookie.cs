using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for AddRedirectCookie
/// </summary>
public class AddRedirectCookie
{
    public void AddRedirCookie(HttpContext hc)
    {
        int RAND = RandomNumber(100000, 999999);
        hc.Session["IdentityNo"] = RAND;
        FormsAuthenticationTicket ticket =
        new FormsAuthenticationTicket(1, "Test", DateTime.Now, DateTime.Now.AddSeconds(900), false, RAND.ToString());
        string encryptedText = FormsAuthentication.Encrypt(ticket);
        hc.Response.Cookies.Remove("__COUNSCOOKIE__");
        //hc.Response.Cookies.Add(new HttpCookie("__COUNSCOOKIE__", encryptedText));
        HttpCookie mycookie = new HttpCookie("__COUNSCOOKIE__", encryptedText);
        mycookie.HttpOnly = true;
        hc.Response.Cookies.Add(mycookie);
    }
    private int RandomNumber(int min, int max)
    {
        Random random = new Random();
        return random.Next(min, max);
    }
}