using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for userData
/// </summary>
public class userData
{
    public string Role;
    public string PI_Instcode;
    public string PI_Instname;
    public string LoginActiveStatus;
    public string PWD;
    public string Opt;
    /// <summary>
    /// chkUserLogin Method return Boolean Value,
    /// if User ID and PWD is valid then it return TRUE
    /// else it will return FALSE
    /// </summary>
    /// <param name="sLoginID">
    /// sLoginID will be Loginid for a user
    /// </param>
    /// <param name="sMatchPWD">
    /// sMatchPWD should be an increpted password, which is
    /// increpted by MD5 at client side
    /// </param>
    /// <param name="sPwdSalt">
    /// sPwdSalt is a salt which will be used with MD5 for
    /// increption
    /// </param>
    /// <param name="conn">
    /// It is a connection name which we want to use from web.config
    /// </param>
    /// <returns>
    /// THIS METHOD RETURN true/false
    /// </returns>
    public Boolean chkUserLogin(string sLoginID, string sMatchPWD, string sPwdSalt)
    {
        SqlConnection myCon = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["conn_stgring"].ConnectionString);
        string sUserPWD;
        SqlCommand myCmd = new SqlCommand("userData", myCon);        
        myCmd.CommandType = CommandType.StoredProcedure;
        myCmd.Parameters.Add("@Action", SqlDbType.VarChar, 25).Value = "chkUserLogin";
        myCmd.Parameters.Add("@User_Id", SqlDbType.VarChar, 15).Value = sLoginID;
        try
        {
            sUserPWD = "";
                if (myCon.State == ConnectionState.Open)
                {
                    myCon.Close();
                }
                myCon.Open();
                SqlDataReader myDR = myCmd.ExecuteReader(CommandBehavior.CloseConnection);
                    
                    while (myDR.Read())
                    {
                        sUserPWD = myDR["PWD"].ToString();

                        if (sUserPWD.Equals("")) return false;
                        sUserPWD = sPwdSalt + sUserPWD;
                        sUserPWD = System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(sUserPWD, "MD5");

                        if (sUserPWD.ToLower().Equals(sMatchPWD.Trim())) 
                        {
                            Opt = myDR["User_id"].ToString();
                            Role = myDR["User_Role"].ToString();
                            PI_Instcode = myDR["Inst_Code"].ToString();
                            PI_Instname = myDR["Inst_name"].ToString();
                            LoginActiveStatus = "A";
                            PWD = myDR["PWD"].ToString();
                            return true; 
                        }
                        else return false;
                    };
                    if (myCon.State == ConnectionState.Open)
                    {
                        myCon.Close();
                    }
                    return false;
        }
        catch (Exception Ex)
        {
            logEntry(sLoginID, Ex.ToString());
            return false;
        }

    }

    /// <summary>
    /// chkLoginDetail Method return a SqlDataReader Object,
    /// This data reader holds, Details about the User
    /// </summary>
    /// <param name="sLoginID">
    /// sLoginID will be Loginid for a user
    /// </param>
    /// <param name="conn">
    /// It is a connection name which we want to use from web.config
    /// </param>
    /// <returns>
    /// This Method Return Data Reader with Information about valide user
    /// </returns>
    public SqlDataReader chkLoginDetail(string sLoginID)
    {
        SqlConnection myCon = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["conn_stgring"].ConnectionString);
        SqlCommand myCmd = new SqlCommand("userData", myCon);
        SqlDataReader myDR;
        myCmd.CommandType = CommandType.StoredProcedure;
        myCmd.Parameters.Add("@Action", SqlDbType.VarChar, 25).Value = "chkLoginDetail";
        myCmd.Parameters.Add("@User_Id", SqlDbType.VarChar, 15).Value = sLoginID;
        try
        {
            if (myCon.State == ConnectionState.Open)
            {
                myCon.Close();
            }
            myCon.Open();
            myDR = myCmd.ExecuteReader();
            
            return myDR;
        }
        catch (Exception Ex)
        {
            logEntry(sLoginID, Ex.ToString());
            myCmd = new SqlCommand("SELECT	xtype FROM sysobjects s WHERE 1=2", myCon);
            myCmd.CommandType = CommandType.Text;
            if (myCon.State == ConnectionState.Open)
            {
                myCon.Close();
            }
            myCon.Open();
            myDR = myCmd.ExecuteReader();
            return myDR;
        }
    }

    /// <summary>
    /// logEntry Method take three parameter,
    /// it update insert remark in log table.
    /// </summary>
    /// <param name="sLoginID">
    /// sLoginID will be Loginid for a user
    /// </param>
    /// <param name="conn">
    /// It is a connection name which we want to use from web.config
    /// </param>
    /// <param name="Remark">
    /// Remark variable is passed at the time of invoking method
    /// </param>
    public void logEntry(string sLoginID, string Remark )
    {
        SqlConnection myCon = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["conn_stgring"].ConnectionString);
        SqlCommand myCmd = new SqlCommand("sp_logintra", myCon);
        myCmd.CommandType = CommandType.StoredProcedure;
        
        myCmd.Parameters.Add("@LoginId",SqlDbType.VarChar,50).Value = sLoginID;
        myCmd.Parameters.Add("@Remarks", SqlDbType.VarChar, 255).Value = Remark;
        try
        {
            if (myCon.State == ConnectionState.Open)
            {
                myCon.Close();
            }
            myCon.Open();
            myCmd.ExecuteNonQuery();
            myCon.Close();
        }
        catch (Exception Ex)
        {
            logEntry(sLoginID, Ex.ToString());
        }
    }


}
