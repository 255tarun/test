using System;
using System.Web;
using System.Collections;
using System.Web.Services;
using System.Web.Services.Protocols;


public class ws_RandomSalt 
{
    public ws_RandomSalt () {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    

    private static int RandomNumber(int min, int max)
    {
        Random random = new Random();
        return random.Next(min, max);
    }

    [WebMethod]
    public Int32 getrndno()
    {
        int intPasswordSalt = RandomNumber(1111111, 9999999);
        return intPasswordSalt;
    }

}

