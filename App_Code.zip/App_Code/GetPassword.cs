﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Security.Cryptography;

/// <summary>
/// Summary description for GetPassword
/// </summary>
public class GetPassword
{
	public GetPassword()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    private static string PASSWORD_CHARS_AlphaCap = "ABCDEFGHJKMNPQRSTWXYZ";
    private static string PASSWORD_CHARS_Alpha = "abcdefghjkmnpqrstwxyz";
    private static string PASSWORD_CHARS_NUMERIC = "23456789";
    private static string PASSWORD_CHARS_SPECIAL = "@$";
    public enum RandomPasswordOptions
    {
        Alpha = 1,
        Numeric = 2,
        Special = 3,
        AlphaCap = 4
    }
    public static string Generate(int passwordLength,
                                 RandomPasswordOptions option)
    {
        return GeneratePassword(passwordLength, option);
    }
    private static string GeneratePassword(int passwordLength,
                                           RandomPasswordOptions option)
    {
        if (passwordLength < 0) return null;

        string passwordChars = GetCharacters(option);

        if (string.IsNullOrEmpty(passwordChars)) return null;

        char[] password = new char[passwordLength];

        for (int i = 0; i < passwordLength; i++)
        {
            int index = GetRandom().Next(passwordChars.Length);
            char passwordChar = passwordChars[index];

            password[i] = passwordChar;
        }

        return new string(password);
    }
    private static string GetCharacters(RandomPasswordOptions option)
    {
        switch (option)
        {
            case RandomPasswordOptions.Alpha:
                return PASSWORD_CHARS_Alpha;
            case RandomPasswordOptions.Numeric:
                return PASSWORD_CHARS_NUMERIC;
            case RandomPasswordOptions.Special:
                return PASSWORD_CHARS_SPECIAL;
            case RandomPasswordOptions.AlphaCap:
                return PASSWORD_CHARS_AlphaCap;
            default:
                break;
        }
        return string.Empty;
    }
    public static Random GetRandom()
    {
        byte[] randomBytes = new byte[4];

        RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider();
        rng.GetBytes(randomBytes);

        int seed = (randomBytes[0] & 0x7f) << 24 |
                    randomBytes[1] << 16 |
                    randomBytes[2] << 8 |
                    randomBytes[3];

        return new Random(seed);
    }
    public static string ScrambleWord(string word)
    {
        char[] chars = new char[word.Length];

        int index = 0;

        while (word.Length > 0)
        {
            int next = GetRandom().Next(0, word.Length - 1);
            chars[index] = word[next];

            word = word.Substring(0, next) + word.Substring(next + 1);

            ++index;
        }
        return new String(chars);
    }
}