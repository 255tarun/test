﻿using System;
using System.Web;

public partial class ErrorPage : System.Web.UI.Page
{
    protected override void OnInit(EventArgs e)
    {
        base.OnInit(e);
        ViewStateUserKey = Session.SessionID;
    }
    string PageName;
    protected void Page_Load(object sender, EventArgs e)
    {
        Response.AppendHeader("Cache-Control", "no-cache"); //HTTP 1.1
        Response.AppendHeader("Cache-Control", "private"); // HTTP 1.1
        Response.AppendHeader("Cache-Control", "no-store"); // HTTP 1.1
        Response.AppendHeader("Cache-Control", "must-revalidate"); // HTTP 1.1
        Response.AppendHeader("Cache-Control", "max-stale=0"); // HTTP 1.1 
        Response.AppendHeader("Cache-Control", "post-check=0"); // HTTP 1.1 
        Response.AppendHeader("Cache-Control", "pre-check=0"); // HTTP 1.1 
        Response.AppendHeader("Pragma", "no-cache"); // HTTP 1.1 
        Response.AppendHeader("Keep-Alive", "timeout=3, max=993"); // HTTP 1.1 
        Response.AppendHeader("Expires", "Mon, 26 Jul 1997 05:00:00 GMT"); // HTTP 1.1
        try
        {
            PageName = "ErrorPage";

            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            if (ViewStateUserKey.ToString() != Session.SessionID.ToString())
            {

                Response.Redirect("LogoutPage.aspx");
            }
            if (Session["LoginActiveStatus"] != null )
            {
                if (Session["Error_Msg"] != null)
                {
                    lbl1.Text = Session["Error_Msg"].ToString();
                }
                hrf_error.HRef = "HomePage.aspx";
            }
            if (Session["Error_Msg"] == null)
            {
                Session["Error_Msg"] = "Please Retry";
            }
            lbl1.Text = Session["Error_Msg"].ToString();
            LogInfo.LockLogInfo(Convert.ToString(Session["RegistrationId"]), PageName, "Error", Session["Error_Msg"].ToString(), Request.UserHostAddress, DateTime.Now);
        }
        catch
        { }
        finally
        {
            Session.Abandon();
        }
    }
}