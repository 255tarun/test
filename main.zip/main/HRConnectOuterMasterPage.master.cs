﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class HRConnectOuterMasterPage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string activepage = Request.RawUrl;
        if (activepage.Contains("HomePage.aspx"))
        {
            liPageID1.Attributes.Add("class", "active");
            liPageID11.Attributes.Add("class", "active");
        }
        else if (activepage.Contains("AboutNAV.aspx"))
        {
            liPageID2.Attributes.Add("class", "active");
            liPageID22.Attributes.Add("class", "active");
        }
        else if (activepage.Contains("HRConnectGallery.aspx"))
        {
            liPageID3.Attributes.Add("class", "active");
            liPageID33.Attributes.Add("class", "active");
        }
        else if (activepage.Contains("Message.aspx"))
        {
            liPageID4.Attributes.Add("class", "active");
            liPageID44.Attributes.Add("class", "active");
        }
        else if (activepage.Contains("LoginPage.aspx"))
        {
            liPageID5.Attributes.Add("class", "active");
            liPageID55.Attributes.Add("class", "active");
        }
    }
}
