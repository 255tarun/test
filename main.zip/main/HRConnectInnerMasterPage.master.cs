﻿using System;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;

public partial class HRConnectInnerMasterPage : System.Web.UI.MasterPage
{
    DataClassesDataContext objmain = new DataClassesDataContext();

    public class ClearCache : IHttpHandler
    {
        public bool IsReusable
        {
            get { return true; }
        }

        public void ProcessRequest(HttpContext context)
        {
            foreach (DictionaryEntry item in context.Cache)
                context.Cache.Remove(item.Key as string);

            context.Response.ContentType = "text/html";
            //context.Response.Write("Cache cleared.");
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["EmpID"] == null || Session["UserName"] == null || Session["Role"] == null || Session["LoginActiveStatus"] == null)
        {
            Response.Redirect("LogoutPage.aspx");
        }
        else
        {
            Response.AddCacheItemDependency("Pages");

            Response.Cache.SetExpires(DateTime.UtcNow.AddMinutes(-1));
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Cache.SetNoStore();

            Response.Cache.SetProxyMaxAge(new TimeSpan(0, 0, 0)); //Cache-Control: s-maxage=0
            Response.Cache.SetValidUntilExpires(false);
            Response.Cache.SetRevalidation(HttpCacheRevalidation.AllCaches);//Cache-Control:  must-revalidate

            Response.AppendHeader("Cache-Control", "no-cache"); //HTTP 1.1
            Response.AppendHeader("Cache-Control", "private"); // HTTP 1.1
            Response.AppendHeader("Cache-Control", "no-store"); // HTTP 1.1
            Response.AppendHeader("Cache-Control", "must-revalidate"); // HTTP 1.1
            Response.AppendHeader("Cache-Control", "max-stale=0"); // HTTP 1.1 
            Response.AppendHeader("Cache-Control", "post-check=0"); // HTTP 1.1 
            Response.AppendHeader("Cache-Control", "pre-check=0"); // HTTP 1.1 
            Response.AppendHeader("Pragma", "no-cache"); // HTTP 1.1 
            Response.AppendHeader("Keep-Alive", "timeout=3, max=993"); // HTTP 1.1 
            Response.AppendHeader("Expires", "Mon, 26 Jul 1997 05:00:00 GMT"); // HTTP 1.1

            FormsAuthenticationTicket ticket = FormsAuthentication.Decrypt(Request.Cookies["__COUNSCOOKIE__"].Value);

            if (Session["IdentityNo"].ToString() != ticket.UserData)
            {
                Session.Clear(); Session.Abandon();
                if (Request.Cookies["ASP.NET_SessionId"] != null)
                {
                    Response.Cookies["ASP.NET_SessionId"].Value = string.Empty;
                    Response.Cookies["ASP.NET_SessionId"].Expires = DateTime.Now.AddMonths(-20);
                }

                if (Request.Cookies["AuthToken"] != null)
                {
                    Response.Cookies["AuthToken"].Value = string.Empty;
                    Response.Cookies["AuthToken"].Expires = DateTime.Now.AddMonths(-20);
                }

                if (Request.Cookies["__COUNSCOOKIE__"] != null)
                {
                    Response.Cookies["__COUNSCOOKIE__"].Value = string.Empty;
                    Response.Cookies["__COUNSCOOKIE__"].Expires = DateTime.Now.AddMonths(-20);
                }
                Server.Transfer("HomePage.aspx");
            }

            AddRedirectCookie CreateCookie = new AddRedirectCookie();
            CreateCookie.AddRedirCookie(HttpContext.Current);

            if (Session["Role"].ToString() != "" && Session["AuthToken"] != null && Request.Cookies["AuthToken"] != null)
            {
                if (!Session["AuthToken"].ToString().Equals(Request.Cookies["AuthToken"].Value))
                {
                    Session.Clear(); Session.Abandon();
                    if (Request.Cookies["ASP.NET_SessionId"] != null)
                    {
                        Response.Cookies["ASP.NET_SessionId"].Value = string.Empty;
                        Response.Cookies["ASP.NET_SessionId"].Expires = DateTime.Now.AddMonths(-20);
                    }

                    if (Request.Cookies["AuthToken"] != null)
                    {
                        Response.Cookies["AuthToken"].Value = string.Empty;
                        Response.Cookies["AuthToken"].Expires = DateTime.Now.AddMonths(-20);
                    }

                    if (Request.Cookies["__COUNSCOOKIE__"] != null)
                    {
                        Response.Cookies["__COUNSCOOKIE__"].Value = string.Empty;
                        Response.Cookies["__COUNSCOOKIE__"].Expires = DateTime.Now.AddMonths(-20);
                    }
                    // redirect to the login page in real application
                    Server.Transfer("HomePage.aspx");
                }
                else
                {
                    if (!Page.IsPostBack)
                    { }
                }
            }

            Page.Title = "HR Connect";

            ltrUserName.Text = Session["UserName"].ToString();
            ltrUserName1.Text = Session["UserName"].ToString();

            imgUserProfilePic.Src = "images/akshay2.png";
            imgUserProfilePicMobile.Src = "images/akshay1.png";


            string activepage = Request.RawUrl;
            if (activepage.Contains("Dashboard.aspx"))
            {
                liPageID1.Attributes.Add("class", "active");
                liPageID2.Attributes.Remove("class");
                liPageID3.Attributes.Remove("class");
                liPageID4.Attributes.Remove("class");
                liPageID5.Attributes.Remove("class");
            }
            if (activepage.Contains("EmpPRB.aspx"))
            {
                liPageID1.Attributes.Remove("class");
                liPageID2.Attributes.Add("class", "active");
                liPageID3.Attributes.Remove("class");
                liPageID4.Attributes.Remove("class");
                liPageID5.Attributes.Remove("class");
            }
            else if (activepage.Contains("Profile.aspx"))
            {
                liPageID1.Attributes.Remove("class");
                liPageID2.Attributes.Remove("class");
                liPageID3.Attributes.Add("class", "active");
                liPageID4.Attributes.Remove("class");
                liPageID5.Attributes.Remove("class");
            }
            else if (activepage.Contains("TestReport.aspx"))
            {
                liPageID1.Attributes.Remove("class");
                liPageID2.Attributes.Remove("class");
                liPageID3.Attributes.Remove("class");
                liPageID4.Attributes.Add("class", "active");
                liPageID5.Attributes.Remove("class");
            }
            else if (activepage.Contains("Subscription_New.aspx"))
            {
                liPageID1.Attributes.Remove("class");
                liPageID2.Attributes.Remove("class");
                liPageID3.Attributes.Remove("class");
                liPageID4.Attributes.Remove("class");
                liPageID5.Attributes.Add("class", "active");
            }

            switch (Convert.ToInt16(Session["Role"]))
            {
                case 1:
                    break;
                case 2:
                    break;
                case 3:
                    break;
                default:
                    break;
            }
        }
    }
}
