﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class LoginPage : System.Web.UI.Page
{
    protected override void OnInit(EventArgs e)
    {
        base.OnInit(e);
        ViewStateUserKey = Session.SessionID;
    }
    string PageName;
    protected void Page_Load(object sender, EventArgs e)
    {
        PageName = "Student Login Page";
        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        if (ViewStateUserKey.ToString() != Session.SessionID.ToString())
        {
            Session.Abandon();
            //Response.Redirect("LogoutPage.aspx");
        }

        if (!Page.IsPostBack)
        {
            Response.Cookies.Remove("__COUNSCOOKIE__");
        }
    }
}