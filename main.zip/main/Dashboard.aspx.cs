﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Data;
using System.Reflection;
using System.Text;

public partial class Dashboard : System.Web.UI.Page
{
    DataClassesDataContext objmain = new DataClassesDataContext();
    protected override void OnInit(EventArgs e)
    {
        base.OnInit(e);
        ViewStateUserKey = Session.SessionID;
    }
    string PageName;
    protected void Page_Load(object sender, EventArgs e)
    {
        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        PageName = "Dashboard";
        if (ViewStateUserKey.ToString() != Session.SessionID.ToString())
        {
            Session.Abandon();
            Response.Redirect("LogoutPage.aspx");
        }
        if (Session["EmpID"] == null || Session["UserName"] == null || Session["Role"] == null || Session["LoginActiveStatus"] == null)
        {
            Session.Abandon();
            Response.Redirect("LogoutPage.aspx");
        }


        Page.Header.Title = "HR Connect - Dashboard";

        if (!IsPostBack)
        {
            LogInfo.LockLogInfo(Session["EmpID"].ToString(), PageName, "Page Load", "Page Load Successfully", Request.UserHostAddress, DateTime.Now);
        }
    }
}

