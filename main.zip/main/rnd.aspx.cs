﻿using System;
using System.Web;

public partial class rnd : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {}

    [System.Web.Services.WebMethod()]

    public static string getrndno1()
    {
        ws_RandomSalt psalt = new ws_RandomSalt();
        string pswd;
        int intPasswordSalt = psalt.getrndno();
        pswd = System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(intPasswordSalt.ToString(), "MD5");
        HttpContext.Current.Session["PSalt"] = pswd;
        return pswd;
    }
}