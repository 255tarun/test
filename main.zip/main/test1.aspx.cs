﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class test1 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnCode_Click(object sender, EventArgs e)
    {
        System.Web.UI.HtmlControls.HtmlGenericControl dynDiv =
            new System.Web.UI.HtmlControls.HtmlGenericControl("DIV");
        dynDiv.ID = "dynDivCode";
        dynDiv.Style.Add(HtmlTextWriterStyle.BackgroundColor, "Gray");
        dynDiv.Style.Add(HtmlTextWriterStyle.Height, "20px");
        dynDiv.Style.Add(HtmlTextWriterStyle.Width, "300px");
        dynDiv.InnerHtml = "I was created using Code Behind";
        this.Controls.Add(dynDiv);
    }
}