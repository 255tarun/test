﻿using System;
using System.Linq;
using System.Web;
using System.Web.UI;

public partial class EmpProfile : System.Web.UI.Page
{
    DataClassesDataContext objmain = new DataClassesDataContext();
    protected override void OnInit(EventArgs e)
    {
        base.OnInit(e);
        ViewStateUserKey = Session.SessionID;
    }
    string PageName;
    protected void Page_Load(object sender, EventArgs e)
    {
        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        PageName = "EmpProfile";
        if (ViewStateUserKey.ToString() != Session.SessionID.ToString())
        {
            Session.Abandon();
            Response.Redirect("LogoutPage.aspx");
        }
        if (Session["EmpID"] == null || Session["UserName"] == null || Session["Role"] == null || Session["LoginActiveStatus"] == null)
        {
            Session.Abandon();
            Response.Redirect("LogoutPage.aspx");
        }


        Page.Header.Title = "HR Connect - Profile";

        if (!IsPostBack)
        {
            FillDetails();
            LogInfo.LockLogInfo(Session["EmpID"].ToString(), PageName, "Page Load", "Page Load Successfully", Request.UserHostAddress, DateTime.Now);
        }
    }

    protected void FillDetails()
    {
        try
        {
            var query = objmain.EmployeeProfile((int)Session["EmpID"]).FirstOrDefault();

            if (query != null)
            {
                ltrEmpMobile.Text = query.EmpMobile.ToString();
                ltrPhone.Text = query.Phone.ToString();
                ltrEmpEmail.Text = query.EmpEmail.ToString();

                ltrCorresAddress.Text = query.CorresAddress1.ToString() + ", " + query.CorresAddress2.ToString() + ", " + query.CorresCity.ToString() + ", " +
                                        query.CorresState.ToString() + " - " + query.CorresZipCode.ToString();
                ltrPermaAddress.Text = query.PermaAddress1.ToString() + ", " + query.PermaAddress2.ToString() + ", " + query.PermaCity.ToString() + ", " +
                                        query.PermaState.ToString() + " - " + query.PermaZipCode.ToString();
                txtFullName.Text = query.EmpName.ToString();

                txtSex.Text = query.Sex.ToString();
                txtDOB.Text = query.DOB.ToString();
                txtMarriageAnniversaryDate.Text = query.MarriageAnniversaryDate.ToString();
                txtDOJ.Text = query.DOJ.ToString();

                LogInfo.LockLogInfo(Session["EmpID"].ToString(), PageName, "View Employee Profile successfully", "View Employee Profile successfully", Request.UserHostAddress, DateTime.Now);
            }
        }
        catch (Exception Ex)
        {
            LogInfo.LockLogInfo(Session["EmpID"].ToString(), PageName, "View Employee Profile unsuccessfull", "View Employee Profile unsuccessfull", Request.UserHostAddress, DateTime.Now);
        }
    }
}