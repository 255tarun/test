﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Logins_WebControlLogin : System.Web.UI.UserControl
{
    DataClassesDataContext objmain = new DataClassesDataContext();

    string connectionString = ConfigurationManager.ConnectionStrings["conn_stgring"].ConnectionString;
    SqlConnection con = new SqlConnection();
    string PageName;
    protected string PostBackStr;
    protected void Page_PreRender(object sender, System.EventArgs e)
    {
        txtEmpID.Text = "";
        //txtPassword.Text = "";
        txtCaptcha.Text = "";
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        PostBackStr = Page.ClientScript.GetPostBackEventReference(this, "MyCustomArgument");
        string strEventargs = Request["__EVENTARGUMENT"];
        PageName = "LoginPage";
        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        Response.Cache.SetNoStore();

        con.ConnectionString = connectionString;

        if (!Page.IsPostBack)
        { }
        else if (strEventargs != null && strEventargs == "MyCustomArgument")
        {
            btnSubmit_Click();
        }
    }

    protected void btnSubmit_Click()
    {
        Boolean LoginStatus = false;
        if (validate_from())
        {
            if (txtEmpID.Text.Trim() != "")
            {
                string value = txtEmpID.Text;

                try
                {
                    //var query = objmain.LoginMasters.Where(x => x.EmpID == Convert.ToInt32(txtEmpID.Text.Trim()) && x.IsActive == 'A').Select(x => new { x.EmpID,  x.Password, x.RolesID }).SingleOrDefault();

                    //var query = objmain.LoginMasters
                    //    .Join(objmain.EmployeeDetails, lm => lm.EmpID, ed => ed.EmpID, (lm, ed) => new { lm, ed })
                    //    .Where(x => x.EmpID == txtEmpID.Text.Trim() && x.IsActive == 'A')
                    //    .Select(x => new { x.EmpID, ed.EmpName, x.Password, x.RolesID }).SingleOrDefault();

                    var query = (from lm in objmain.LoginMasters
                                 join ed in objmain.EmployeeDetails on lm.EmpID equals ed.EmpId
                                 where lm.EmpID == Convert.ToInt32(txtEmpID.Text.Trim()) && lm.IsActive == 'A'
                                 select new
                                 {
                                     EmpID = lm.EmpID,
                                     Password = lm.Password,
                                     RolesID = lm.RolesID,
                                     EmpName = ed.EmpName
                                 }).SingleOrDefault();


                    if (query != null)
                    {
                        string strUserPassword = query.Password;
                        if (strUserPassword == null)
                        {
                            LogInfo.LockLogInfo(txtEmpID.Text.Trim(), PageName, "Error", "User Id or Password is Incorrect. Or User is not Authorized.", Request.UserHostAddress, DateTime.Now);
                            ScriptManager.RegisterStartupScript(Page, this.GetType(), "d", "alert('User Id or Password is Incorrect. Or User is not Authorized.');", true);
                            return;
                        }
                        else
                        {
                            strUserPassword = Session["PSalt"].ToString() + strUserPassword;
                            strUserPassword = System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(strUserPassword, "MD5");

                            //string strMatchPassword = Session["PSalt"].ToString() + System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(txtEmpID.Text.Trim() + "Nav#1234", "MD5").ToLower();
                            //strMatchPassword = System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(strMatchPassword, "MD5");

                            if (strUserPassword.ToLower().Equals(txtPassword.Text.Trim()))
                            {
                                string guid = Guid.NewGuid().ToString();
                                Session["AuthToken"] = guid;
                                HttpCookie testcookie = new HttpCookie("AuthToken", guid);
                                testcookie.HttpOnly = true;
                                // now create a new cookie with this guid value
                                Response.Cookies.Add(testcookie);

                                AddRedirectCookie CreateCookie = new AddRedirectCookie();
                                CreateCookie.AddRedirCookie(HttpContext.Current);

                                LogInfo.LockLogInfo(txtEmpID.Text.Trim(), PageName, "Status Checked", "Login Successful ", Request.UserHostAddress, DateTime.Now);

                                Session.Remove("PSalt");
                                Session["EmpID"] = query.EmpID;
                                Session["Role"] = query.RolesID;
                                Session["UserName"] = query.EmpName;
                                Session["LoginActiveStatus"] = "A";

                                // Comment bcoz property Authenticated is missing....?
                                #region UpdateLoginTable
                                DateTime Insert_LoginDateTime = new DateTime();
                                Insert_LoginDateTime = DateTime.Parse(DateTime.Now.ToString(), System.Globalization.CultureInfo.CreateSpecificCulture("en-AU").DateTimeFormat);

                                var ObjTblLoginMaster = (from login in objmain.LoginMasters
                                                         where login.EmpID == Convert.ToInt32(txtEmpID.Text.Trim())
                                                         select login
                                                        ).Single();

                                ObjTblLoginMaster.LoginStatus = 'A';
                                ObjTblLoginMaster.LastLoginIPAddress = Request.UserHostAddress;
                                ObjTblLoginMaster.LastLoginDate = Insert_LoginDateTime;
                                try
                                {
                                    objmain.LoginMasters.Context.SubmitChanges();
                                    objmain.SubmitChanges();
                                }
                                catch
                                { }
                                #endregion

                                //if (strUserPassword.ToLower().Equals(strMatchPassword.ToLower()))
                                //{
                                //    Response.Redirect("ChangePasswordCompulsary.aspx", false);
                                //}
                                //else
                                //{
                                    Response.Redirect("Dashboard.aspx", false);
                                //}
                            }
                            else
                            {
                                LogInfo.LockLogInfo(txtEmpID.Text.Trim(), PageName, "Error", "Encrypt password Not match.", Request.UserHostAddress, DateTime.Now);
                                ScriptManager.RegisterStartupScript(Page, this.GetType(), "d", "alert('Your Login Id or Password is Incorrect. Try Again.');", true);
                                Session.Remove("PSalt");
                                return;
                            }
                        }
                    }
                    else
                    {
                        LogInfo.LockLogInfo(txtEmpID.Text.Trim(), PageName, "Error", "User Id is Incorrect. Or User is not Authorized.", Request.UserHostAddress, DateTime.Now);
                        ScriptManager.RegisterStartupScript(Page, this.GetType(), "d", "alert('Your User Id is Incorrect. Or You are not Authorized');", true);
                    }
                }
                catch (SqlException sqlEx)
                {
                    LogInfo.LockLogInfo(txtEmpID.Text.Trim(), PageName, "Sql Exception", @"SQL Exception Occured :"
                + sqlEx.Number.ToString() + " :" + sqlEx.Message.ToString() + " :" + sqlEx.Source.ToString(), Request.UserHostAddress, DateTime.Now);
                    Session["Error_Msg"] = "Some Error occured, please try after some time.";
                    Response.Redirect("ErrorPage.aspx");
                }
                catch (LinqDataSourceValidationException Ldsvc)
                {
                    LogInfo.LockLogInfo(txtEmpID.Text.Trim(), PageName, "Exception Error", Ldsvc.Message, Request.UserHostAddress, DateTime.Now);
                    Session["Error_Msg"] = "Some Error occured, please try after some time.";
                    Response.Redirect("ErrorPage.aspx");
                }
                catch (Exception Ex)
                {
                    LogInfo.LockLogInfo(txtEmpID.Text.Trim(), PageName, "Exception", @"Exception Occured :"
                + Ex.Message.ToString() + " :" + Ex.Source.ToString(), Request.UserHostAddress, DateTime.Now);
                    Session["Error_Msg"] = "Some Error occured, please try after some time.";
                    Response.Redirect("ErrorPage.aspx");
                }
                finally
                { }
            }
            else
            {
                ScriptManager.RegisterStartupScript(Page, this.GetType(), "d", "alert('Invalid Input');", true);
            }
        }
        else
        {
            txtEmpID.Text = "";
            txtPassword.Text = "";
            txtCaptcha.Text = "";
        }
    }
    protected Boolean validate_from()
    {
        string regularExpressionForEmpID = @"^[0-9]{4,9}$";
        if (txtEmpID.Text.Trim() == "")
        {
            ScriptManager.RegisterStartupScript(Page, this.GetType(), "d", "alert('Please Enter Emp ID');", true);
            return false;
        }
        if (txtEmpID.Text.Trim().Length < 4)
        {
            ScriptManager.RegisterStartupScript(Page, this.GetType(), "d", "alert('Please Enter Emp ID');", true);
            return false;
        }
        if (!Regex.IsMatch(txtEmpID.Text.Trim(), regularExpressionForEmpID))
        {
            ScriptManager.RegisterStartupScript(Page, this.GetType(), "d", "alert('Please Enter Valid Emp ID');", true);
            return false;
        }
        if (txtPassword.Text == "")
        {
            ScriptManager.RegisterStartupScript(Page, this.GetType(), "d", "alert('Please Enter Password');", true);
            return false;
        }
        if (txtCaptcha.Text.Trim() == "")
        {
            ScriptManager.RegisterStartupScript(Page, this.GetType(), "d", "alert('Please Enter Security Code');", true);
            return false;
        }
        if (txtCaptcha.Text.Trim().Length != 6)
        {
            ScriptManager.RegisterStartupScript(Page, this.GetType(), "d", "alert('Please Enter Valid Security Code');", true);
            return false;
        }
        if (!string.IsNullOrWhiteSpace(this.Session["CaptchaImageText"].ToString()) && this.Session["CaptchaImageText"].ToString() != txtCaptcha.Text.ToString().Trim())
        {
            ScriptManager.RegisterStartupScript(Page, this.GetType(), "d", "alert('Please Enter Valid Security Code');", true);
            return false;
        }
        return true;
    }
}